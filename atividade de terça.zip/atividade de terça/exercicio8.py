numeros = [5, 12, 8, 20, 33, 7, 15, 40, 2, 18]

numero_busca = int(input("Digite um número para buscar: "))

if numero_busca in numeros:
    posicao = numeros.index(numero_busca)
    print(f"O número {numero_busca} está na lista.")
    print("Posição (Índice):", posicao)
else:
    print(f"O número {numero_busca} NÃO está na lista.")