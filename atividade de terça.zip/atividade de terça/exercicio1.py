numeros = [10, 25, 7, 42, 18]

print("Todos os valores:")
for numero in numeros:
    print(numero)

print("\nMaior número:", max(numeros))
print("Menor número:", min(numeros))