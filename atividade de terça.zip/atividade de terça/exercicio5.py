numeros = list(range(1, 21))

print("Números pares:")
for numero in numeros:
    if numero % 2 == 0:
        print(numero)