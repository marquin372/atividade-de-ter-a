nomes = ["Ana", "Bruno", "Carlos", "Daniela", "Eduardo"]

print("Todos os nomes:")
for nome in nomes:
    print(nome)

print("\nPrimeiro nome:", nomes[0])
print("Último nome:", nomes[-1])
print("Quantidade de nomes:", len(nomes))